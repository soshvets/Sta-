from app.crud.crud_departments import CRUDDepartment
from app.crud.crud_workers import CRUDWorkers
from app.crud.crud_salary import CRUDSalary