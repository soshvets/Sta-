from app.schema.child import Child
from app.schema.salary import Salary
from app.schema.worker import Worker
from app.schema.department import DepartmentCreate, Department, DepartmentBase