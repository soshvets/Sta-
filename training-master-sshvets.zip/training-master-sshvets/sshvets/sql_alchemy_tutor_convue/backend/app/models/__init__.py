from app.models.department import Department
from app.models.worker import Worker
from app.models.salary import Salary