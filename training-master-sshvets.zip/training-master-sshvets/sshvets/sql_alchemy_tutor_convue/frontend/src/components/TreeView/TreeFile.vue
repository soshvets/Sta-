<template>
  <div class="uk-flex">
    <button class="uk-button uk-button-primary ">ICON</button>
    <p>{{name}}</p>    
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  props: {
    name: String,
  }
}
</script>

<style>

</style>
