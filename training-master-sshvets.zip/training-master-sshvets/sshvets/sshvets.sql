Create table worker
(
      PESEL varchar(11) CONSTRAINT check_pesel CHECK((LENGTH(PESEL)=11) AND (PESEL ~ '^\d{11}$' )) PRIMARY KEY,
      imie varchar(50) not null,
      nazwisko varchar not null,
	  iddep integer not null REFERENCES department(iddep),
	  obywatelstwo varchar not null,
	  wiek integer not null,
	  czy_karany boolean,
	  dzieci jsonb
);

CREATE TABLE department
(
	iddep integer UNIQUE PRIMARY KEY,
	nazwa varchar UNIQUE NOT NULL,
	ulica varchar NOT NULL,
	miasto varchar NOT NULL,
	kod_pocztowy varchar(5) CONSTRAINT check_kod_pocztowy CHECK(kod_pocztowy ~ '^\d{2}-\d{3}$')
	
);

CREATE TABLE salary
(
	pesel varchar(11) CONSTRAINT check_pesel CHECK((LENGTH(pesel)=11) AND (pesel ~ '^\d{11}$' )) PRIMARY KEY REFERENCES worker(PESEL),
	miesiac date not null,
	salary double precision not null CONSTRAINT check_salary CHECK(salary > 0)
	
);

